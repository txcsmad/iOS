//
//  MADNextViewController.m
//  TargetAction
//
//  Created by Comyar Zaheri on 11/7/13.
//  Copyright (c) 2013 Comyar Zaheri. All rights reserved.
//

#import "MADNextViewController.h"

@implementation MADNextViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.modalTransitionStyle = UIModalTransitionStyleCoverVertical;
        
        self.view.backgroundColor = [UIColor redColor];
        
        /* Initialize Button */
        self.dismissButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [self.dismissButton setFrame:CGRectMake(0, 0, 128, 64)];
        [self.dismissButton setCenter:self.view.center];
        [self.dismissButton setTitle:@"Dismiss" forState:UIControlStateNormal];
        [self.dismissButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [self.dismissButton setTitleColor:[UIColor blueColor] forState:UIControlStateHighlighted];
        
        /// TODO Add target-action for button
        [self.dismissButton addTarget:self action:@selector(tappedButton:) forControlEvents:UIControlEventTouchUpInside];
        
        [self.view addSubview:self.dismissButton];
    }
    return self;
}

- (void)tappedButton:(UIButton *)button
{
    [self.delegate dismissNextViewController];
}


@end
