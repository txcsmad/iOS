//
//  MADMainViewController.m
//  TargetAction
//
//  Created by Comyar Zaheri on 11/7/13.
//  Copyright (c) 2013 Comyar Zaheri. All rights reserved.
//

#import "MADMainViewController.h"


@implementation MADMainViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.view.backgroundColor = [UIColor blueColor];
        
        /* Initialize Button */
        self.button = [UIButton buttonWithType:UIButtonTypeCustom];
        [self.button setFrame:CGRectMake(0, 0, 128, 64)];
        [self.button setCenter:self.view.center];
        [self.button setTitle:@"Click Me" forState:UIControlStateNormal];
        [self.button setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [self.button setTitleColor:[UIColor blueColor] forState:UIControlStateHighlighted];
        
        /// TODO Add target-action for button
        [self.button addTarget:self action:@selector(tappedButton:) forControlEvents:UIControlEventTouchUpInside];
        
        [self.view addSubview:self.button];
        
        /* Initilize Next View Controller */
        self.nextViewController = [[MADNextViewController alloc]init];
        self.nextViewController.delegate = self;
    }
    return self;
}

- (void)tappedButton:(UIButton *)button
{
    [self presentViewController:self.nextViewController animated:YES completion:nil];
}

- (void)dismissNextViewController
{
    [self.nextViewController dismissViewControllerAnimated:YES completion:nil];
}

@end
