//
//  MADAppDelegate.h
//  TargetAction
//
//  Created by Comyar Zaheri on 11/7/13.
//  Copyright (c) 2013 Comyar Zaheri. All rights reserved.
//

#import <UIKit/UIKit.h>

@class MADMainViewController;

@interface MADAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) MADMainViewController *mainViewController;

@end
