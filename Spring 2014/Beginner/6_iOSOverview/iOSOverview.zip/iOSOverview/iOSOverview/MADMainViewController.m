//
//  MADMainViewController.m
//  iOSOverview
//
//  Created by Comyar Zaheri on 3/18/14.
//  Copyright (c) 2014 Comyar Zaheri. All rights reserved.
//

#import "MADMainViewController.h"
#import "UIImage+ImageEffects.h"


#pragma mark - MADMainViewController Class Extension

@interface MADMainViewController ()

/**
 
 ----------------------------------------------------------------------
 2.
 ----------------------------------------------------------------------
 
 - Create the following properties in MADMainViewController's Class Extension
    - UIButton      *startButton, attributes: strong, nonatomic
    - UIImage       *backgroundImage, attributes: strong, nonatomic
    - UIImageView   *backgroundImageView, attributes: strong, nonatomic
 
 */

@end


#pragma mark - MADMainViewController Implementation

@implementation MADMainViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        /**
         
         ----------------------------------------------------------------------
         3. Initialize backgroundImage
         ----------------------------------------------------------------------
         
         The name of the background image is "menuBackground"
         
         
         - Use Apple's documentation and choose the right method to initialize backgroundImage
            - hint: you should be using a class method
         
            https://developer.apple.com/library/ios/documentation/UIKit/Reference/UIImage_Class/Reference/Reference.html
         
         */
        
        
        // 4. Uncomment the following line after initializing the backgroundImage
        // self.backgroundImage = [self.backgroundImage applyDarkEffect];
        
        
        /**
         
         ----------------------------------------------------------------------
         5. Initialize the backgroundImageView
         ----------------------------------------------------------------------
         
         - Use Apple's documentation to choose the right method to initialize backgroundImageView
         
         https://developer.apple.com/library/ios/documentation/UIKit/Reference/UIImageView_Class/Reference/Reference.html
         
         - add the backgroundImageView as a subview of this view controller's view
         
         */
        
        
        /**
         
         ----------------------------------------------------------------------
         6. Initialize the startButton
         ----------------------------------------------------------------------
         
         - Use [UIButton buttonWithType:UIButtonTypeSystem] to initialize the startButton
         - Customize the button:
            - Set its title to "Start". hint - use setTitle:ForState:
            - Change the text color to white. hint - use setTitleColor:ForState:
         
         NOTE: Complete #7 before #8
         */
        
        /**
         
         ----------------------------------------------------------------------
         8. Add a target and action to startButton
         ----------------------------------------------------------------------
         
         - use addTarget:action:forControlEvents: so that didTouchUpInsideButton: gets called when
           the user touches the startButton
            hint: target should be self
            hint: actions should always use the @selector() decorator
            hint: the control event should be UIControlEventTouchUpInside
         */
    }
    
    return self;
}

/**
 
 ----------------------------------------------------------------------
 7. define didTouchUpInsideButton:
 ----------------------------------------------------------------------
 
 - Define a method called didTouchUpInsideButton: that takes a UIButton* as a parameter
 - make a print out "I am done with part one!!!!"
    hint use NSLog
 
 - Get Comyar's attention if you're done with this step
 
 */


@end
