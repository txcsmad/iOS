//
//  MADAppDelegate.m
//  iOSOverview
//
//  Created by Comyar Zaheri on 3/18/14.
//  Copyright (c) 2014 Comyar Zaheri. All rights reserved.
//

#import "MADAppDelegate.h"
#import "MADMainViewController.h"

@implementation MADAppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    self.window.backgroundColor = [UIColor whiteColor];
    
    /**
     
     ----------------------------------------------------------------------
     1. Start Here
     ----------------------------------------------------------------------
     
     - Create an instance of MADMainViewController
     - Make the new instance of MADMainViewController the root view controller
     
     */
    
    
    [self.window makeKeyAndVisible];
    return YES;
}

@end
