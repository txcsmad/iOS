//
//  MADMainViewController.h
//  CoreAnimation
//
//  Created by Comyar Zaheri on 11/19/13.
//  Copyright (c) 2013 Comyar Zaheri. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MADMainViewController : UIViewController

/// Ball Image Views
@property (strong, nonatomic) UIImageView *blueBallImageView;
@property (strong, nonatomic) UIImageView *grayBallImageView;
@property (strong, nonatomic) UIImageView *redBallImageView;
@property (strong, nonatomic) UIImageView *greenBallImageView;
@property (strong, nonatomic) UIImageView *purpleBallImageView;

@end
