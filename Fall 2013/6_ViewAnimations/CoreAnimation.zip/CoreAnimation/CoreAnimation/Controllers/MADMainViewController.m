//
//  MADMainViewController.m
//  CoreAnimation
//
//  Created by Comyar Zaheri on 11/19/13.
//  Copyright (c) 2013 Comyar Zaheri. All rights reserved.
//

#import "MADMainViewController.h"

#pragma mark - MADMainViewController Class Extension

@interface MADMainViewController ()

/// Ball Images
@property (strong, nonatomic) UIImage *blueBallImage;
@property (strong, nonatomic) UIImage *grayBallImage;
@property (strong, nonatomic) UIImage *redBallImage;
@property (strong, nonatomic) UIImage *purpleBallImage;
@property (strong, nonatomic) UIImage *greenBallImage;

/// Start Points
@property (assign, nonatomic) CGPoint blueStartPoint;
@property (assign, nonatomic) CGPoint redStartPoint;
@property (assign, nonatomic) CGPoint greenStartPoint;
@property (assign, nonatomic) CGPoint purpleStartPoint;
@property (assign, nonatomic) CGPoint grayStartPoint;

@end

#pragma mark - MADMainViewController Implementation

@implementation MADMainViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        [self initializeBlueBall];
        [self initializeGreenBall];
        [self initializeRedBall];
        [self initializePurpleBall];
        [self initializeGrayBall];
    }
    return self;
}

#pragma mark UIViewController Methods

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    
    [UIView animateWithDuration:10.0 delay:0.0 usingSpringWithDamping:0.1 initialSpringVelocity:10.0 options:UIViewAnimationOptionCurveLinear animations:^ {
        self.blueBallImageView.center = self.view.center;
    }completion:nil];

    [UIView animateWithDuration:5.0 animations: ^ {
        self.greenBallImageView.backgroundColor = [UIColor blackColor];
        self.greenBallImageView.center = CGPointMake(self.view.center.x, self.view.bounds.size.height - self.greenBallImage.size.height);
        self.greenBallImageView.transform = CGAffineTransformRotate(self.greenBallImageView.transform, 180);
    }];

    [UIView animateWithDuration:8.0 animations: ^ {
        self.redBallImageView.center = CGPointMake(self.view.bounds.size.width - self.redBallImage.size.width, self.view.bounds.size.height - self.redBallImage.size.height);
    } completion: ^ (BOOL finished) {
        [UIView animateWithDuration:5.0 animations: ^ {
            self.redBallImageView.center = self.redStartPoint;
        }];
    }];

    [UIView animateWithDuration:10.0 delay:0.0 options:UIViewAnimationOptionCurveEaseOut animations:^ {
        self.purpleBallImageView.bounds = CGRectMake(0, 0, 1.0 * self.purpleBallImage.size.width, 2.0 * self.purpleBallImage.size.height);
    }completion: ^ (BOOL finished) {
        [UIView animateWithDuration:5.0 animations: ^ {
            self.purpleBallImageView.bounds = CGRectMake(0, 0, self.purpleBallImage.size.width, self.purpleBallImage.size.height);
        }];
    }];

    [UIView animateWithDuration:10.0 delay:0.0 usingSpringWithDamping:0.01 initialSpringVelocity:1.0 options:UIViewAnimationOptionCurveEaseIn animations:^ {
        self.grayBallImageView.alpha = 0.0;
    }completion:nil];
}

#pragma mark Initialize Balls

- (void)initializeBlueBall
{
    self.blueStartPoint = CGPointMake(0, 0);
    self.blueBallImage = [UIImage imageNamed:@"blue"];
    self.blueBallImageView = [[UIImageView alloc]initWithImage:self.blueBallImage];
    [self.blueBallImageView setFrame:CGRectMake(self.blueStartPoint.x,
                                                self.blueStartPoint.y,
                                                self.blueBallImage.size.width,
                                                self.blueBallImage.size.height)];
    [self.view addSubview:self.blueBallImageView];
}

- (void)initializeGreenBall
{
    self.greenStartPoint = CGPointMake(157, 31);
    self.greenBallImage = [UIImage imageNamed:@"green"];
    self.greenBallImageView = [[UIImageView alloc]initWithImage:self.greenBallImage];
    [self.greenBallImageView setFrame:CGRectMake(self.greenStartPoint.x,
                                                 self.greenStartPoint.y,
                                                 self.greenBallImage.size.width,
                                                 self.greenBallImage.size.height)];
    [self.view addSubview:self.greenBallImageView];
}


- (void)initializeRedBall
{
    self.redStartPoint = CGPointMake(56, 78);
    self.redBallImage = [UIImage imageNamed:@"red"];
    self.redBallImageView = [[UIImageView alloc]initWithImage:self.redBallImage];
    [self.redBallImageView setFrame:CGRectMake(self.redStartPoint.x,
                                                 self.redStartPoint.y,
                                                 self.redBallImage.size.width,
                                                 self.redBallImage.size.height)];
    [self.view addSubview:self.redBallImageView];
}

- (void)initializePurpleBall
{
    self.purpleStartPoint = CGPointMake(100, 50);
    self.purpleBallImage = [UIImage imageNamed:@"purple"];
    self.purpleBallImageView = [[UIImageView alloc]initWithImage:self.purpleBallImage];
    [self.purpleBallImageView setFrame:CGRectMake(self.purpleStartPoint.x,
                                               self.purpleStartPoint.y,
                                               self.purpleBallImage.size.width,
                                               self.purpleBallImage.size.height)];
    [self.view addSubview:self.purpleBallImageView];
}

- (void)initializeGrayBall
{
    self.grayStartPoint = CGPointMake(200, 150);
    self.grayBallImage = [UIImage imageNamed:@"gray"];
    self.grayBallImageView = [[UIImageView alloc]initWithImage:self.grayBallImage];
    [self.grayBallImageView setFrame:CGRectMake(self.grayStartPoint.x,
                                                  self.grayStartPoint.y,
                                                  self.grayBallImage.size.width,
                                                  self.grayBallImage.size.height)];
    [self.view addSubview:self.grayBallImageView];
}

@end
