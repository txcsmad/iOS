//
//  MADMainScene.h
//  SpriteKitIntro
//
//  Created by Comyar Zaheri on 12/3/13.
//  Copyright (c) 2013 Comyar Zaheri. All rights reserved.
//

#import <SpriteKit/SpriteKit.h>

@interface MADMainScene : SKScene
@property (strong, nonatomic) SKLabelNode   *labelNode;
@property (strong, nonatomic) SKSpriteNode  *pandaNode;
@property (strong, nonatomic) SKSpriteNode  *ballNode;
@property (strong, nonatomic) SKVideoNode   *videoNode;
@end
