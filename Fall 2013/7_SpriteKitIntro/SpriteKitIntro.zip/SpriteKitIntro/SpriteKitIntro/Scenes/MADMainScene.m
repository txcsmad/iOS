//
//  MADMainScene.m
//  SpriteKitIntro
//
//  Created by Comyar Zaheri on 12/3/13.
//  Copyright (c) 2013 Comyar Zaheri. All rights reserved.
//

#import "MADMainScene.h"

@interface MADMainScene ()
@property (strong, nonatomic) SKAction *spinAction;
@property (strong, nonatomic) SKAction *fadeinAction;
@property (strong, nonatomic) SKAction *fadoutAction;
@property (strong, nonatomic) SKPhysicsBody *ballPhysicsBody;
@end

@implementation MADMainScene

- (id)initWithSize:(CGSize)size
{
    if(self = [super initWithSize:size]) {
        self.backgroundColor = [UIColor whiteColor];
        [self initializeActions];
        [self initializeLabelNode];
        [self initializeSpriteNodes];
        [self initializeBallPhysicsBody];
        [self initializeVideoNode];
    }
    return self;
}

- (void)initializeActions
{
    self.spinAction = [SKAction rotateByAngle:2 * M_PI duration:1.0];
    self.fadeinAction = [SKAction fadeInWithDuration:1.0];
    self.fadoutAction = [SKAction fadeOutWithDuration:1.0];
}

- (void)initializeLabelNode
{
    self.labelNode = [[SKLabelNode alloc]initWithFontNamed:@"Helvetica"];
    self.labelNode.text = @"Hello World";
    self.labelNode.fontSize = 32;
    self.labelNode.fontColor = [UIColor blackColor];
    self.labelNode.position = CGPointMake(self.size.width / 2, self.size.height - 5 * self.labelNode.fontSize);
    [self addChild:self.labelNode];
}

- (void)initializeSpriteNodes
{
    self.pandaNode = [[SKSpriteNode alloc]initWithImageNamed:@"panda"];
    self.pandaNode.anchorPoint = CGPointMake(0.5, 0.5);
    self.pandaNode.position = CGPointMake(self.size.width / 4, self.size.height / 2);
    [self addChild:self.pandaNode];
    
    self.ballNode = [[SKSpriteNode alloc]initWithImageNamed:@"green"];
    self.ballNode.anchorPoint = CGPointMake(0.5, 0.5);
    self.ballNode.position = CGPointMake(self.size.width / 2, self.size.height);
    [self addChild:self.ballNode];
}

- (void)initializeBallPhysicsBody
{
    self.ballPhysicsBody = [SKPhysicsBody bodyWithCircleOfRadius:self.ballNode.size.width];
    self.ballPhysicsBody.dynamic = YES;
    self.ballPhysicsBody.affectedByGravity = YES;
    self.ballPhysicsBody.mass = 1;
    self.ballPhysicsBody.linearDamping = 1.0;
    self.ballNode.physicsBody = self.ballPhysicsBody;
}

- (void)initializeVideoNode
{
    self.videoNode = [SKVideoNode videoNodeWithVideoFileNamed:@"yolo.mp4"];
    self.videoNode.anchorPoint = CGPointMake(0.5, 0.5);
    self.videoNode.size = CGSizeMake(160, 80);
    self.videoNode.position = CGPointMake(self.size.width / 2, self.size.height / 3);
    [self addChild:self.videoNode];
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [self.videoNode play];
    
    [self.videoNode runAction:[SKAction sequence:@[self.spinAction,
                                                   [SKAction moveTo:CGPointZero duration:1.0],
                                                   [SKAction moveTo:CGPointMake(self.size.width / 2, self.size.height / 3) duration:1.0]]]];
    
    [self.labelNode runAction:self.spinAction completion:^ {
        [self.labelNode runAction:self.fadoutAction completion: ^ {
            [self.labelNode runAction:self.fadeinAction];
        }];
    }];
    
    [self.pandaNode runAction:[SKAction sequence:@[[SKAction colorizeWithColor:[UIColor redColor] colorBlendFactor:1.0 duration:1.0],
                                                    [SKAction waitForDuration:1.0],
                                                    [SKAction colorizeWithColorBlendFactor:0.0 duration:1.0]]]];
}

- (void)didSimulatePhysics
{
    if(self.ballNode.position.y <= self.ballNode.size.height / 2.0) {
        self.ballPhysicsBody.velocity = CGVectorMake(self.ballPhysicsBody.velocity.dx, -1.0 * self.ballPhysicsBody.velocity.dy);
        if(self.ballPhysicsBody.velocity.dy <= 0.1) {
            self.ballPhysicsBody.affectedByGravity = NO;
        }
    }
}



@end
