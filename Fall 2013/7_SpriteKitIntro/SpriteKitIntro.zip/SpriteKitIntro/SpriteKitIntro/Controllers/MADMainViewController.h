//
//  MADMainViewController.h
//  SpriteKitIntro
//
//  Created by Comyar Zaheri on 12/3/13.
//  Copyright (c) 2013 Comyar Zaheri. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <SpriteKit/SpriteKit.h>

@class MADMainScene;

@interface MADMainViewController : UIViewController
@property (strong, nonatomic) MADMainScene *mainScene;
@end
