//
//  MADMainViewController.m
//  SpriteKitIntro
//
//  Created by Comyar Zaheri on 12/3/13.
//  Copyright (c) 2013 Comyar Zaheri. All rights reserved.
//

#import "MADMainViewController.h"
#import "MADMainScene.h"

@interface MADMainViewController ()
@property (strong, nonatomic) SKView *spriteView;
@end

@implementation MADMainViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        self.spriteView = [[SKView alloc]initWithFrame:self.view.bounds];
        self.view = self.spriteView;
        
        self.mainScene = [[MADMainScene alloc]initWithSize:self.view.bounds.size];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.spriteView.showsNodeCount = YES;
    self.spriteView.showsDrawCount = YES;
    self.spriteView.showsFPS = YES;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self.spriteView presentScene:self.mainScene];
}

@end
