//
//  MADViewController.m
//  Objective-C_Lab_I
//
//  Created by Comyar Zaheri on 9/26/13.
//  Copyright (c) 2013 Comyar Zaheri. All rights reserved.
//

#import "MADViewController.h"



@interface MADViewController ()

@end

@implementation MADViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)loginButtonPressed
{
    NSLog(@"Login Button Pressed");
    NSString *usernameEntered = self.usernameField.text;
    NSString *passwordEntered = self.passwordField.text;
    
    if([usernameEntered isEqualToString:kUsername] &&
       [passwordEntered isEqualToString:kPassword]) {
        NSLog(@"Right Password!");
        [self performSegueWithIdentifier:@"LoginSegue" sender:self];
    } else {
        NSLog(@"Wrong Password!");
        self.usernameField.text = @"";
        self.passwordField.text = @"";
    }
    
}

@end
