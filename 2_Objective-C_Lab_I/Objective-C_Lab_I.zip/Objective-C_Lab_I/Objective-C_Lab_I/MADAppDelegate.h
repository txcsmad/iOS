//
//  MADAppDelegate.h
//  Objective-C_Lab_I
//
//  Created by Comyar Zaheri on 9/26/13.
//  Copyright (c) 2013 Comyar Zaheri. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MADAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
