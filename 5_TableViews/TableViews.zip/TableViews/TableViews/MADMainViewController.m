//
//  MADMainViewController.m
//  TableViews
//
//  Created by Comyar Zaheri on 11/14/13.
//  Copyright (c) 2013 Comyar Zaheri. All rights reserved.
//

#import "MADMainViewController.h"

#pragma mark - MADMainViewController Implementation

@implementation MADMainViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        _candies = @[@"raspberry-vanilla", @"caramel-vanilla", @"cocoa", @"fruity", @"vanilla", @"berry"];
        
        self.tableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 20, self.view.bounds.size.width, self.view.bounds.size.height - 20) style:UITableViewStylePlain];
        self.tableView.dataSource = self;
        self.tableView.delegate = self;
        [self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"cellID"];
        [self.view addSubview:self.tableView];
        
        
    }
    return self;
}

#pragma mark UITableViewDataSource Methods

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *tableViewCell = [tableView dequeueReusableCellWithIdentifier:@"cellID"];
    tableViewCell.textLabel.text = _candies[indexPath.row];
    tableViewCell.textLabel.textColor = [UIColor redColor];
    return tableViewCell;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [_candies count];
}

#pragma mark UITableViewDelegate Methods

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 20 * indexPath.row + 40;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *tableViewCell = [tableView cellForRowAtIndexPath:indexPath];
    NSString *candyName = tableViewCell.textLabel.text;
    NSLog(@"%@", candyName);
}


@end
