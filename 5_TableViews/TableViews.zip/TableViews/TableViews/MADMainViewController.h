//
//  MADMainViewController.h
//  TableViews
//
//  Created by Comyar Zaheri on 11/14/13.
//  Copyright (c) 2013 Comyar Zaheri. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MADMainViewController : UIViewController <UITableViewDataSource, UITableViewDelegate>
{
    NSArray *_candies;
}

@property (strong, nonatomic) UITableView *tableView;

@end
