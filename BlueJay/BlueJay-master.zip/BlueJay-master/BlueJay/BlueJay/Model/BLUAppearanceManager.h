//
//  BLUAppearanceManager.h
//  BlueJay
//
//  Created by Comyar Zaheri on 10/8/13.
//  Copyright (c) 2013 Comyar Zaheri. All rights reserved.
//

#import <Foundation/Foundation.h>

/** MACROS */
#define kNAVIGATION_BAR_TINT_COLOR              [UIColor colorWithRed:0.019 green:0.705 blue:0.90 alpha:1.0]
#define kNAVIGATION_BAR_TITLE_TEXT_ATTRIBUTES   [NSDictionary dictionaryWithObjectsAndKeys:\
                                                [UIFont fontWithName:@"Helvetica" size:24],NSFontAttributeName,\
                                                [UIColor whiteColor], NSForegroundColorAttributeName,nil]

/**
 BLUAppearanceManager manages the default appearance of standard UI elements
 throughout our app.
 */
@interface BLUAppearanceManager : NSObject

/////////////////////////////////////////
// @name Using the Appearance Manager
/////////////////////////////////////////

/**
 Set the appearance of the navigation bar throughout the application
 */
+ (void)setNavigationBarAppearance;

@end
