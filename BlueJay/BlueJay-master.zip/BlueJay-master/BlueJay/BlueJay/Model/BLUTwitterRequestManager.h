//
//  BLUTwitterRequestManager.h
//  BlueJay
//
//  Created by Comyar Zaheri on 10/10/13.
//  Copyright (c) 2013 Comyar Zaheri. All rights reserved.
//

#import <Foundation/Foundation.h>

#define kNUM_TIMELINE_TWEETS_TO_REQUEST 5

/**
 BLUTwitterRequestManager provides a simple-to-use interface for making API requests to Twitter
 necessary for BlueJay's functionality.
 */
@interface BLUTwitterRequestManager : NSObject

/////////////////////////////////////////
// @name Using the Request Manager
/////////////////////////////////////////

/**
 Request's the user's timeline.
 @param account User's Twitter account
 @param handler Completion handler block to be executed when request is finished
 */
+ (void)performTwitterTimelineRequestForAccount:(ACAccount *)account completion:(SLRequestHandler)handler;

@end
