//
//  BLUAppearanceManager.m
//  BlueJay
//
//  Created by Comyar Zaheri on 10/8/13.
//  Copyright (c) 2013 Comyar Zaheri. All rights reserved.
//

#import "BLUAppearanceManager.h"

@implementation BLUAppearanceManager

+ (void)setNavigationBarAppearance
{
    [[UINavigationBar appearance]setBarTintColor:kNAVIGATION_BAR_TINT_COLOR];
    [[UINavigationBar appearance]setTitleTextAttributes:kNAVIGATION_BAR_TITLE_TEXT_ATTRIBUTES];
}

@end
