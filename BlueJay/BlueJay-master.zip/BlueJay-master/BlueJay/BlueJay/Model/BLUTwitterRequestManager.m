//
//  BLUTwitterRequestManager.m
//  BlueJay
//
//  Created by Comyar Zaheri on 10/10/13.
//  Copyright (c) 2013 Comyar Zaheri. All rights reserved.
//

#import "BLUTwitterRequestManager.h"

@implementation BLUTwitterRequestManager

+ (void)performTwitterTimelineRequestForAccount:(ACAccount *)account completion:(SLRequestHandler)handler
{
    /// This URL is defined by Twitter's API and is the same for each request
    static NSString *timelineURLRequestString = @"https://api.twitter.com/1.1/statuses/user_timeline.json";
    
    /// We set our parameters for our request to customize the reponse we actual receive
    NSDictionary *timelineRequestParams = @{@"screen_name": account.username,   /// username
                                            @"include_rts": @"0",               /// Include Retweets?
                                            @"trim_user": @"1",                 /// Reduce the amount of user data?
                                            @"count": [NSString stringWithFormat:@"%d", kNUM_TIMELINE_TWEETS_TO_REQUEST] /// Number of items
                                            };
    
    /// Finally, we create our request
    SLRequest   *timelineRequest = [SLRequest requestForServiceType:SLServiceTypeTwitter
                                                      requestMethod:SLRequestMethodGET
                                                                URL:[NSURL URLWithString:timelineURLRequestString]
                                                         parameters:timelineRequestParams];
    /// Associate our request with the user's account
    [timelineRequest setAccount:account];
    
    /// Perform the request
    [timelineRequest performRequestWithHandler:handler];
}

@end
