//
//  BLUAccountManager.h
//  BlueJay
//
//  Created by Comyar Zaheri on 10/7/13.
//  Copyright (c) 2013 Comyar Zaheri. All rights reserved.
//

#import <Foundation/Foundation.h>

/// Completion handler for access requests to the user's Twitter account
typedef void (^TwitterAccountRequestCompletionBlock) (BOOL, NSError *);

/**
 BLUAccountManager is a singleton class that provides a simple-to-use API for requesting access to and using
 user accounts throughout the application
 */
@interface BLUAccountManager : NSObject

/////////////////////////////////////////
// @name Getting an Account Manager
/////////////////////////////////////////

/**
 Returns a shared instance of the account manager
 @returns A singleton account manager
 */
+ (instancetype)sharedAccountManager;

/////////////////////////////////////////
// @name Using an Account Manager
/////////////////////////////////////////

/**
 YES if the user has setup Twitter in the device Settings
 @returns YES if the user has access to Twitter
 */
+ (BOOL)hasTwitterAccess;

/////////////////////////////////////////
// @name Properties
/////////////////////////////////////////

/// Account store that requests access to user accounts
@property (strong, nonatomic, readonly) ACAccountStore  *accountStore;

/// Reference to a TwitterAccountType
@property (strong, nonatomic, readonly) ACAccountType   *twitterAccountType;

/// List of Twitter accounts available on the device
@property (strong, nonatomic, readonly) NSArray         *twitterAccounts;

@end
