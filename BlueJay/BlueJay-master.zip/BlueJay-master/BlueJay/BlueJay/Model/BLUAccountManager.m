//
//  BLUAccountManager.m
//  BlueJay
//
//  Created by Comyar Zaheri on 10/7/13.
//  Copyright (c) 2013 Comyar Zaheri. All rights reserved.
//

#import "BLUAccountManager.h"

#pragma mark - BLUAccountManager implementation

@implementation BLUAccountManager
@synthesize accountStore        = _accountStore;
@synthesize twitterAccountType  = _twitterAccountType;
@synthesize twitterAccounts     = _twitterAccounts;

#pragma mark Getting an Account Manager

+ (instancetype)sharedAccountManager
{
    static BLUAccountManager *sharedAccountManager = nil;
    
    /// This is using a feature of Grand Central Dispatch that allows for
    /// one-time code execution. The code in the following block is executed
    /// only once, regardless of subsequent method calls
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^ {
        sharedAccountManager = [[BLUAccountManager alloc]initWithAccountTypeIdentifier:ACAccountTypeIdentifierTwitter];
    });
    return sharedAccountManager;
}

- (instancetype)initWithAccountTypeIdentifier:(NSString *)accountTypeIdentifier
{
    if(self = [super init]) {
        self->_accountStore = [[ACAccountStore alloc]init];
        self->_twitterAccountType = [self.accountStore accountTypeWithAccountTypeIdentifier:accountTypeIdentifier];
    }
    return self;
}

- (instancetype)init
{
    /// Allowing instances of BLUAccountManager to be created this way would violate the singleton paradigm
    /// Therefore, we disallow it completely
    [NSException raise:@"BLUSingletonException" format:@"Cannot initialize an instance of a singleton"];
    return nil;
}

#pragma mark Using an Account Manager

+ (BOOL)hasTwitterAccess
{
    return [SLComposeViewController isAvailableForServiceType:SLServiceTypeTwitter];
}

#pragma mark Overridden Getters

- (NSArray *)twitterAccounts
{
    if(!self->_twitterAccounts)
        self->_twitterAccounts = [self.accountStore accountsWithAccountType:self.twitterAccountType];
    return self->_twitterAccounts;
}

@end
