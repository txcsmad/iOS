//
//  BLUAppDelegate.h
//  BlueJay
//
//  Created by Comyar Zaheri on 10/6/13.
//  Copyright (c) 2013 Comyar Zaheri. All rights reserved.
//

#import <UIKit/UIKit.h>

@class BLUMainViewController;

@interface BLUAppDelegate : UIResponder <UIApplicationDelegate>

/////////////////////////////////////////
// @name Properties
/////////////////////////////////////////

/// Application window. All views rendered in this window.
@property (strong, nonatomic)           UIWindow                *window;

/// Root view controller
@property (strong, nonatomic, readonly) BLUMainViewController   *mainViewController;

@end
