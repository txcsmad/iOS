//
//  main.m
//  BlueJay
//
//  Created by Comyar Zaheri on 10/6/13.
//  Copyright (c) 2013 Comyar Zaheri. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "BLUAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([BLUAppDelegate class]));
    }
}
