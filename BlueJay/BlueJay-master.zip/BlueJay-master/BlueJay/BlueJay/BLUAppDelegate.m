//
//  BLUAppDelegate.m
//  BlueJay
//
//  Created by Comyar Zaheri on 10/6/13.
//  Copyright (c) 2013 Comyar Zaheri. All rights reserved.
//

#import "BLUAppDelegate.h"
#import "BLUAppearanceManager.h"
#import "BLUMainViewController.h"

@implementation BLUAppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    /// Initialize our application window
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    self.window.backgroundColor = [UIColor whiteColor];
    
    /// Set the appearance of our views throughout the application
    [BLUAppearanceManager setNavigationBarAppearance];
    
    /// Initialize the root view controller
    self->_mainViewController = [[BLUMainViewController alloc]initWithNibName:nil bundle:nil];
    self.window.rootViewController = self.mainViewController;
    
    /// Make our window visible to the user
    [self.window makeKeyAndVisible];
    return YES;
}

@end
