//
//  BLUMainViewController.h
//  BlueJay
//
//  Created by Comyar Zaheri on 10/6/13.
//  Copyright (c) 2013 Comyar Zaheri. All rights reserved.
//

#import <UIKit/UIKit.h>

@class BLUAccountManager;

/**
 A BLUMainViewController acts as the application's root view controller. A BLUMainViewController controls user authentication
 and API requests.
 */
@interface BLUMainViewController : UIViewController

//////////////////////////////////////////
// @name Properties
//////////////////////////////////////////

/// Navigation bar at the top of our view controller's view
@property (strong, nonatomic, readonly) UINavigationBar     *navigationBar;

//// Account manager handles user authentication on this view controller's behalf
@property (strong, nonatomic, readonly) BLUAccountManager   *accountManager;

@end
