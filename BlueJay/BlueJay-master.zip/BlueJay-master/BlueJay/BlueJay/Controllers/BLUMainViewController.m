//
//  BLUMainViewController.m
//  BlueJay
//
//  Created by Comyar Zaheri on 10/6/13.
//  Copyright (c) 2013 Comyar Zaheri. All rights reserved.
//

#import "BLUMainViewController.h"
#import "BLUAccountManager.h"
#import "BLUTwitterRequestManager.h"

#pragma mark - BLUMainViewController Class Extension

@interface BLUMainViewController ()

@end

#pragma mark - BLUMainViewController Implementation

@implementation BLUMainViewController
@synthesize navigationBar   = _navigationBar;
@synthesize accountManager  = _accountManager;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        
        /// Retrieve an instance of BLUAccountManager (singleton)
        self->_accountManager = [BLUAccountManager sharedAccountManager];
        
        if([BLUAccountManager hasTwitterAccess]) {
            /// If the user has setup Twitter in Settings, request access to the user's Twitter account
            [self.accountManager.accountStore requestAccessToAccountsWithType:self.accountManager.twitterAccountType options:nil
                                                                   completion: ^ (BOOL granted, NSError *error)
            {
                if(granted) {
                    NSLog(@"User Granted Access! Performing Timeline Request.");
                    [self performTwitterTimelineRequest];
                } else {
                    /// TODO Present an alert to the user that access needs to be given!
                    NSLog(@"User Denied Access!");
                }
            }];
        } else {
            /// TODO Present an alert to the user to setup Twitter!
            NSLog(@"Tell the user to setup Twitter in Settings!");
        }
    }
    return self;
}

- (void)performTwitterTimelineRequest
{
    /// We'll just chose the last twitter account available in our array. In the future, we'll modify this so we can chose which account is used
    ACAccount *twitterAccount = [self.accountManager.twitterAccounts lastObject];
    
    /// Perform the actual request
    [BLUTwitterRequestManager performTwitterTimelineRequestForAccount:twitterAccount completion:^ (NSData *responseData, NSHTTPURLResponse *urlResponse, NSError *error)
     {
         /// Check if we got data and that our HTTP status code was ok
         if(responseData && urlResponse.statusCode >= 200 && urlResponse.statusCode < 300) {
             
             /// The returned data is a JSON document, so we can serialize it into key/values pairings (a dictionary)
             NSError *jsonSerializationError;
             NSDictionary *timelineData = [NSJSONSerialization JSONObjectWithData:responseData options:NSJSONReadingAllowFragments error:&error];
             
             /// If there were no errors during serialization, our timelineData shouldn't be nil
             if(timelineData) {
                 NSLog(@"%@", timelineData);
                 /// From here we can inform the appropriate objects that we have successfully downloaded the user's timeline
                 /// Now we need to parse the returned data and then display it to the user
             } else {
                 NSLog(@"%@", [jsonSerializationError debugDescription]);
                 /// An error occurred when parsing the JSON document
             }
         } else {
             NSLog(@"%@", [error debugDescription]);
             /// An error occurred when downloading the user's timeline
         }
     }];
}

- (void)viewDidLoad
{
    /// Always call the super view's implementation when overriding (unless you know what you're doing)
    [super viewDidLoad];
    
    /// Initialize our view's subviews
    [self initializeNavigationBar];
}

- (UIStatusBarStyle)preferredStatusBarStyle {
    /// Why are we not calling the super view's implementation here?
    /// Because the super view returns a status bar style that we don't want
    return UIStatusBarStyleLightContent;
}

#pragma mark Initialization

- (void)initializeNavigationBar
{
    /// Initialize our navigation bar
    self->_navigationBar = [[UINavigationBar alloc]initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, 64)];
    
    /// Add an item to the navigation bar (this will be our title)
    self.navigationBar.items = @[[[UINavigationItem alloc]initWithTitle:@"BlueJay"]];
    
    /// Add our navigation bar as a subview of our view controller's view
    [self.view addSubview:self.navigationBar];
}

@end
