BlueJay
=======

BlueJay is a sample Twitter client developed as a teaching project for the members of MAD.
