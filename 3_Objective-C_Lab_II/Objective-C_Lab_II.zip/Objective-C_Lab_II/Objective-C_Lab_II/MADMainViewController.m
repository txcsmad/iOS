//
//  MADMainViewController.m
//  Objective-C_Lab_II
//
//  Created by Comyar Zaheri on 10/1/13.
//  Copyright (c) 2013 Comyar Zaheri. All rights reserved.
//

#import "MADMainViewController.h"

@interface MADMainViewController ()

@end

@implementation MADMainViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        
        /// We set the background color of the default view to red
        self.view.backgroundColor = [UIColor redColor];
    }
    return self;
}

@end
