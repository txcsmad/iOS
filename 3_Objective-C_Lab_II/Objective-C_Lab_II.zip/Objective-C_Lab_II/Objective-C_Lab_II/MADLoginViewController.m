//
//  MADLoginViewController.m
//  Objective-C_Lab_II
//
//  Created by Comyar Zaheri on 10/3/13.
//  Copyright (c) 2013 Comyar Zaheri. All rights reserved.
//

#import "MADLoginViewController.h"
#import "MADMainViewController.h"

@interface MADLoginViewController ()

@end

@implementation MADLoginViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    /**
     First we initialize an instance of MADLoginViewController by calling its parent's "constructor"
     the parent is referred to as super
     */
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    
    /**
     This check is a very common convention in iOS dev. It's possible for the parent's constructor to return
     nil. If the parent's constructor returns nil, we also want to return nil so we should not do ANY customization
     */
    if (self) {
        
        /**
         First, we should initialize the view controller's properties
         
         We do this by calling the method initWithFrame: which MADLoginView inherited from UIView
         */
        self.loginView = [[MADLoginView alloc]initWithFrame:self.view.bounds];
        
        /**
         Now we want our view controller to display our login view. There are two ways to do this. 
         First, we can replace this view controller's default view with the login view
         */
        self.view = self.loginView;
        
        /**
         or, we can add the login view as a subview of this view controller's default view
         */
        //        [self.view addSubview:self.loginView];
        
        
        /**
         Here, we want a specific method to be called any time the user touches our button
         
         So we're saying that the method we want to call is called didTouchUpInsideLoginButton: (action) and that method can be found
         on the object self (target). (i.e. The button is going to send the message didPressLoginButton: to self)
         
         Then, we say that we want that message to be sent when the user touched the button and raised their finger without dragging it
         off of the button. (i.e. touch up inside)
         */
        [self.loginView.loginButton addTarget:self action:@selector(didTouchUpInsideLoginButton:) forControlEvents:UIControlEventTouchUpInside];

    }
    return self;
}

- (void)didTouchUpInsideLoginButton:(UIButton *)loginButton
{
    NSLog(@"Pressed Button");
    
    /**
     When the login button is clicked we want to check whether the inputted username and password are 
     the actual username and password we set
     */
    if ([self.loginView.usernameField.text isEqualToString:kUsername] &&
        [self.loginView.passwordField.text isEqualToString:kPassword]) {
        
        /// If they are, then we transition to another view controller (an instance of MADMainViewController)
        [self presentViewController:[[MADMainViewController alloc]initWithNibName:nil bundle:nil] animated:YES completion:nil];
    }
}

@end
