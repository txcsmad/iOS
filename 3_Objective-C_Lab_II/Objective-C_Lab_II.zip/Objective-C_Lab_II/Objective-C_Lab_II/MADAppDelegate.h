//
//  MADAppDelegate.h
//  Objective-C_Lab_II
//
//  Created by Comyar Zaheri on 10/1/13.
//  Copyright (c) 2013 Comyar Zaheri. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MADLoginViewController.h"

@interface MADAppDelegate : UIResponder <UIApplicationDelegate>

/**
 All applications need a window. Any template you use in Xcode will provide a window
 */
@property (strong, nonatomic) UIWindow *window;


@property (strong, nonatomic) MADLoginViewController *loginViewController;

@end
