//
//  MADLoginViewController.h
//  Objective-C_Lab_II
//
//  Created by Comyar Zaheri on 10/3/13.
//  Copyright (c) 2013 Comyar Zaheri. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MADLoginView.h"

#define kUsername @"root"
#define kPassword @"toor"

@interface MADLoginViewController : UIViewController

/**
 loginView is a property of MADLoginViewController. This means that any object can access 
 loginView. By default, all objects have readwrite access to loginView. In future meetings, 
 we'll look at examples of "readonly" properties.
 
 loginView is given two property attributes: strong and nonatomic
 
 strong means that the reference count for loginView is incremented by an instance of MADLoginViewController
 
 nonatomic means that read/write access to loginView are not thread-safe
 */
@property (strong, nonatomic) MADLoginView *loginView;

@end
