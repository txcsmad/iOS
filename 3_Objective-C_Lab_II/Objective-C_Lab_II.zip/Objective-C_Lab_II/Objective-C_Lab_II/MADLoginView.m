//
//  MADLoginView.m
//  Objective-C_Lab_II
//
//  Created by Comyar Zaheri on 10/1/13.
//  Copyright (c) 2013 Comyar Zaheri. All rights reserved.
//

#import "MADLoginView.h"

@implementation MADLoginView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor whiteColor];
        
        /**
         All of our properties first
         */
        self.usernameField = [[UITextField alloc]initWithFrame:CGRectMake(64, 64, 256, 44)];
        self.usernameField.center = CGPointMake(self.center.x, self.usernameField.center.y);
        self.usernameField.placeholder = @"Username"; /// Set placeholder text
        
        self.passwordField = [[UITextField alloc]initWithFrame:CGRectMake(64, 128, 256, 44)];
        self.passwordField.center = CGPointMake(self.center.x, self.passwordField.center.y);
        self.passwordField.placeholder = @"Password"; /// Set placeholder text
        
        
        /**
         buttonWithType: is a class method of UIButton. These sorts of methods are called "factories" because
         they return a brand-new instance of the class every time they're called
         */
        self.loginButton = [UIButton buttonWithType:UIButtonTypeSystem];
        self.loginButton.frame = CGRectMake(0, 0, 128, 44);
        self.loginButton.center = self.center;
        [self.loginButton setTitle:@"Login" forState:UIControlStateNormal];
        
        /**
         we HAVE to add all our fields and buttons as subviews of our login view (yes, UITextField is a descendent of UIView
         and UIButton is a descendent of UIView
         */
        [self addSubview:self.usernameField];
        [self addSubview:self.passwordField];
        [self addSubview:self.loginButton];
    }
    return self;
}

@end
