//
//  MADLoginView.h
//  Objective-C_Lab_II
//
//  Created by Comyar Zaheri on 10/1/13.
//  Copyright (c) 2013 Comyar Zaheri. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MADLoginView : UIView

@property (strong, nonatomic) UITextField   *usernameField;
@property (strong, nonatomic) UITextField   *passwordField;
@property (strong, nonatomic) UIButton      *loginButton;

@end
