//
//  MADMainViewController.h
//  Objective-C_Lab_II
//
//  Created by Comyar Zaheri on 10/1/13.
//  Copyright (c) 2013 Comyar Zaheri. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MADLoginView.h"

@interface MADMainViewController : UIViewController


@end
